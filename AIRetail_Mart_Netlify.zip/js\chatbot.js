/**
 * AIRetail Mart - Client-Side Smart POS Assistant Chatbot for Netlify
 */

document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('chatbotToggleBtn');
    const closeBtn = document.getElementById('chatbotCloseBtn');
    const clearBtn = document.getElementById('chatbotClearBtn');
    const chatWindow = document.getElementById('chatbotWindow');
    const chatBody = document.getElementById('chatbotBody');
    const chatForm = document.getElementById('chatbotForm');
    const chatInput = document.getElementById('chatbotInput');
    const typingIndicator = document.getElementById('chatbotTyping');

    if (!toggleBtn || !chatWindow) return;

    toggleBtn.addEventListener('click', () => {
        const isHidden = chatWindow.classList.contains('d-none');
        if (isHidden) {
            chatWindow.classList.remove('d-none');
            toggleBtn.classList.add('chat-active');
            chatInput.focus();
            scrollToBottom();
        } else {
            chatWindow.classList.add('d-none');
            toggleBtn.classList.remove('chat-active');
        }
    });

    closeBtn.addEventListener('click', () => {
        chatWindow.classList.add('d-none');
        toggleBtn.classList.remove('chat-active');
    });

    clearBtn.addEventListener('click', () => {
        chatBody.innerHTML = `
            <div class="chat-message bot-message">
                <div class="bot-msg-avatar"><i class="bi bi-robot"></i></div>
                <div class="msg-bubble">
                    👋 Hi! I am your <strong>AIRetail Mart</strong> Assistant. How can I help you today?
                </div>
            </div>
            <div class="chatbot-suggestions" id="chatbotSuggestions">
                <span class="suggestion-chip" data-query="Today's sales">📊 Today's Sales</span>
                <span class="suggestion-chip" data-query="Show low stock">⚠️ Low Stock</span>
                <span class="suggestion-chip" data-query="Price of Basmati Rice">📦 Price of Rice</span>
                <span class="suggestion-chip" data-query="Recent bills">🧾 Recent Bills</span>
                <span class="suggestion-chip" data-query="Total inventory">📦 Total Stock</span>
            </div>
        `;
        attachSuggestionEvents();
    });

    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = chatInput.value.trim();
        if (!message) return;

        chatInput.value = '';
        appendUserMessage(message);

        // Show typing indicator briefly then reply
        typingIndicator.classList.remove('d-none');
        scrollToBottom();

        setTimeout(() => {
            typingIndicator.classList.add('d-none');
            const res = processBotQuery(message);
            appendBotMessage(res.reply, res.suggestions);
        }, 350);
    });

    function attachSuggestionEvents() {
        document.querySelectorAll('.suggestion-chip').forEach(chip => {
            chip.onclick = () => {
                const query = chip.getAttribute('data-query');
                appendUserMessage(query);
                typingIndicator.classList.remove('d-none');
                scrollToBottom();

                setTimeout(() => {
                    typingIndicator.classList.add('d-none');
                    const res = processBotQuery(query);
                    appendBotMessage(res.reply, res.suggestions);
                }, 300);
            };
        });
    }
    attachSuggestionEvents();

    function appendUserMessage(text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-message user-message';
        msgDiv.innerHTML = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
        chatBody.appendChild(msgDiv);
        scrollToBottom();
    }

    function appendBotMessage(replyHtml, suggestions = []) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-message bot-message';
        
        let suggestionsHtml = '';
        if (suggestions && suggestions.length > 0) {
            suggestionsHtml = `
                <div class="chatbot-suggestions mt-2">
                    ${suggestions.map(s => `<span class="suggestion-chip" data-query="${s}">${s}</span>`).join('')}
                </div>
            `;
        }

        msgDiv.innerHTML = `
            <div class="bot-msg-avatar"><i class="bi bi-robot"></i></div>
            <div class="msg-bubble">
                ${replyHtml}
                ${suggestionsHtml}
            </div>
        `;
        chatBody.appendChild(msgDiv);
        attachSuggestionEvents();
        scrollToBottom();
    }

    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function escapeHtml(string) {
        const div = document.createElement('div');
        div.innerText = string;
        return div.innerHTML;
    }

    // Natural Language Query Engine for Netlify Frontend
    function processBotQuery(text) {
        const q = text.toLowerCase().trim();

        // 1. Greetings
        if (q.match(/\b(hi|hello|hey|namaste|greetings)\b/)) {
            return {
                reply: `👋 <strong>Hello! I am your AIRetail Mart Smart Assistant.</strong><br><br>I can help you monitor live store data, check prices, inspect low-stock items, and guide you through billing.`,
                suggestions: ["📊 Today's Sales", "⚠️ Low Stock", "📦 Price of Rice", "🧾 Recent Bills"]
            };
        }

        // 2. Today's Sales
        if (q.match(/\b(today.*sale|today.*revenue|today.*bill|sales today|earnings)\b/)) {
            const stats = POS.getStats();
            return {
                reply: `📈 <strong>Today's Sales Performance:</strong><br><br>` +
                       `• <strong>Total Revenue:</strong> <span class="text-primary fw-bold">${POS.info.currency}${stats.todayRevenue.toFixed(2)}</span><br>` +
                       `• <strong>Bills Generated:</strong> <span class="fw-bold">${stats.todayBills} invoices</span>`,
                suggestions: ["🧾 Recent Bills", "⚠️ Low Stock", "📦 Total Stock"]
            };
        }

        // 3. Low stock
        if (q.match(/\b(low.*stock|restock|alert|out of stock|shortage)\b/)) {
            const stats = POS.getStats();
            if (stats.lowStockItems.length === 0) {
                return {
                    reply: "✅ <strong>Good news!</strong> All store products are currently well-stocked above their minimum thresholds.",
                    suggestions: ["📊 Today's Sales", "📦 Total Stock"]
                };
            }
            const items = stats.lowStockItems.slice(0, 5).map(p => 
                `• <strong>${p.name}</strong>: <span class="badge bg-danger">${p.stock} left</span> (Min alert: ${p.min_stock})`
            ).join('<br>');

            return {
                reply: `⚠️ <strong>Found ${stats.lowStockItems.length} low-stock product(s) needing attention:</strong><br><br>${items}<br><br><em>Tip: Open the Products page to quick-restock.</em>`,
                suggestions: ["📊 Today's Sales", "📦 Price of Rice"]
            };
        }

        // 4. Product price/stock search
        const matchProd = q.match(/(?:price of|stock of|cost of|do we have|check|find|search for)\s+(.+)/) || q.match(/(?:rice|atta|oil|salt|sugar|coffee|tea|coke|chips|cadbury|maggi|soap|shampoo|notebook|pen)/);
        if (matchProd) {
            let term = typeof matchProd === 'object' && matchProd[1] ? matchProd[1] : matchProd[0];
            term = term.replace(/[\?\.!]/g, '').trim();
            const products = POS.getProducts();
            const matches = products.filter(p => p.name.toLowerCase().includes(term) || p.barcode.includes(term));

            if (matches.length > 0) {
                const list = matches.slice(0, 3).map(p => {
                    const badge = p.stock <= p.min_stock ? `<span class="badge bg-warning text-dark">${p.stock} left</span>` : `<span class="badge bg-success">${p.stock} in stock</span>`;
                    return `• <strong>${p.name}</strong><br>&nbsp;&nbsp;Price: <strong>${POS.info.currency}${p.selling_price.toFixed(2)}</strong> | Stock: ${badge}<br>&nbsp;&nbsp;Barcode: <code>${p.barcode}</code>`;
                }).join('<br><br>');
                return {
                    reply: `🔍 <strong>Search Results for '${term}':</strong><br><br>${list}`,
                    suggestions: ["📊 Today's Sales", "⚠️ Low Stock"]
                };
            } else {
                return {
                    reply: `❌ No products matched <em>'${term}'</em> in the catalog.`,
                    suggestions: ["📦 Total Stock", "📊 Today's Sales"]
                };
            }
        }

        // 5. Recent bills
        if (q.match(/\b(recent|latest|last).*(bill|sale|invoice)\b/)) {
            const sales = POS.getSales();
            if (sales.length === 0) {
                return { reply: "No bills have been generated yet.", suggestions: ["📊 Today's Sales"] };
            }
            const list = sales.slice(0, 3).map(s => 
                `• <a href="invoice.html?inv=${s.invoice_no}"><strong>${s.invoice_no}</strong></a>: ${POS.info.currency}${s.grand_total.toFixed(2)} (${s.payment_method})`
            ).join('<br>');
            return {
                reply: `🧾 <strong>Latest Completed Invoices:</strong><br><br>${list}`,
                suggestions: ["📊 Today's Sales", "⚠️ Low Stock"]
            };
        }

        // 6. Total inventory
        if (q.match(/\b(total.*stock|total.*product|inventory valuation|catalog)\b/)) {
            const stats = POS.getStats();
            return {
                reply: `📦 <strong>Store Inventory Summary:</strong><br><br>` +
                       `• <strong>Total Distinct Products:</strong> ${stats.totalProducts}<br>` +
                       `• <strong>Total Inventory Valuation:</strong> ${POS.info.currency}${stats.inventoryValuation.toFixed(2)}`,
                suggestions: ["⚠️ Low Stock", "📊 Today's Sales"]
            };
        }

        // 7. POS tips
        if (q.match(/\b(tips|shortcuts|how to|guide)\b/)) {
            return {
                reply: `💡 <strong>Helpful POS Tips:</strong><br><br>` +
                       `• <strong>Barcode Scanner</strong>: Type or scan any barcode and press <kbd>Enter</kbd> to add it to the cart instantly.<br>` +
                       `• <strong>Cash Calculator</strong>: Enter the cash received to calculate the change returned automatically.<br>` +
                       `• <strong>Reprinting</strong>: Access past invoices from Billing History at any time.`,
                suggestions: ["📊 Today's Sales", "⚠️ Low Stock"]
            };
        }

        // Fallback
        return {
            reply: `I couldn't quite understand <em>'${text}'</em>.<br><br>Try asking about <strong>Today's sales</strong>, <strong>Low stock</strong>, <strong>Price of Rice</strong>, or <strong>Recent bills</strong>.`,
            suggestions: ["📊 Today's Sales", "⚠️ Low Stock", "📦 Price of Rice", "💡 POS Tips"]
        };
    }
});
