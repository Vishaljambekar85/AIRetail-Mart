/**
 * AIRetail Mart - Centralized Local Storage Data Layer for Netlify
 * Simulates the MySQL database completely within the browser.
 */

const SEED_PRODUCTS = [
    { id: 1, name: 'Royal Basmati Rice 1kg', barcode: '890103038101', category: 'Groceries', selling_price: 120.00, stock: 45, min_stock: 10 },
    { id: 2, name: 'Aashirvaad Whole Wheat Atta 5kg', barcode: '890103038102', category: 'Groceries', selling_price: 245.00, stock: 30, min_stock: 8 },
    { id: 3, name: 'Fortune Sunlite Refined Oil 1L', barcode: '890103038103', category: 'Groceries', selling_price: 155.00, stock: 25, min_stock: 8 },
    { id: 4, name: 'Tata Salt Iodized 1kg', barcode: '890103038104', category: 'Groceries', selling_price: 28.00, stock: 60, min_stock: 15 },
    { id: 5, name: 'Madhur Pure & Hygienic Sugar 1kg', barcode: '890103038105', category: 'Groceries', selling_price: 48.00, stock: 35, min_stock: 10 },

    { id: 6, name: 'Nescafe Classic Coffee Jar 100g', barcode: '890103038201', category: 'Beverages', selling_price: 290.00, stock: 18, min_stock: 5 },
    { id: 7, name: 'Taj Mahal Tea 250g', barcode: '890103038202', category: 'Beverages', selling_price: 170.00, stock: 22, min_stock: 5 },
    { id: 8, name: 'Tropicana Orange Juice 1L', barcode: '890103038203', category: 'Beverages', selling_price: 110.00, stock: 4, min_stock: 6 },
    { id: 9, name: 'Bisleri Mineral Water 1L', barcode: '890103038204', category: 'Beverages', selling_price: 20.00, stock: 80, min_stock: 20 },
    { id: 10, name: 'Coca Cola Can 300ml', barcode: '890103038205', category: 'Beverages', selling_price: 40.00, stock: 3, min_stock: 10 },

    { id: 11, name: 'Lay\'s Classic Salted Chips 50g', barcode: '890103038301', category: 'Snacks', selling_price: 20.00, stock: 50, min_stock: 15 },
    { id: 12, name: 'Kurkure Masala Munch 85g', barcode: '890103038302', category: 'Snacks', selling_price: 20.00, stock: 40, min_stock: 12 },
    { id: 13, name: 'Cadbury Dairy Milk Silk 60g', barcode: '890103038303', category: 'Snacks', selling_price: 85.00, stock: 2, min_stock: 8 },
    { id: 14, name: 'Parle-G Gold Biscuits 200g', barcode: '890103038304', category: 'Snacks', selling_price: 30.00, stock: 65, min_stock: 15 },
    { id: 15, name: 'Maggi 2-Minute Noodles 280g (Pack of 4)', barcode: '890103038305', category: 'Snacks', selling_price: 56.00, stock: 28, min_stock: 10 },

    { id: 16, name: 'Dettol Original Bathing Soap (Pack of 3)', barcode: '890103038401', category: 'Personal Care', selling_price: 135.00, stock: 20, min_stock: 5 },
    { id: 17, name: 'Colgate Strong Teeth Toothpaste 200g', barcode: '890103038402', category: 'Personal Care', selling_price: 98.00, stock: 30, min_stock: 8 },
    { id: 18, name: 'Head & Shoulders Anti-Dandruff 180ml', barcode: '890103038403', category: 'Personal Care', selling_price: 180.00, stock: 5, min_stock: 6 },
    { id: 19, name: 'Nivea Soft Moisturizing Cream 100ml', barcode: '890103038404', category: 'Personal Care', selling_price: 160.00, stock: 12, min_stock: 4 },

    { id: 20, name: 'Vim Dishwash Gel Bottle 500ml', barcode: '890103038501', category: 'Household', selling_price: 105.00, stock: 22, min_stock: 6 },
    { id: 21, name: 'Surf Excel Easy Wash Detergent 1kg', barcode: '890103038502', category: 'Household', selling_price: 140.00, stock: 15, min_stock: 5 },
    { id: 22, name: 'Classmate Long Notebook 172 Pages', barcode: '890103038503', category: 'Stationery', selling_price: 65.00, stock: 40, min_stock: 10 },
    { id: 23, name: 'Cello Butterflow Blue Ball Pen (Pack of 5)', barcode: '890103038504', category: 'Stationery', selling_price: 50.00, stock: 3, min_stock: 10 }
];

const STORE_INFO = {
    name: 'AIRetail Mart',
    tagline: 'Smart AI Billing & Retail Management',
    address: 'Shop No. 14, Commercial Complex, MG Road',
    phone: '+91 98765 43210',
    gstin: '27ABCDE1234F1Z5',
    currency: '₹',
    default_gst_rate: 18.0
};

// Initialize LocalStorage Data if not present
function initStore() {
    if (!localStorage.getItem('pos_products')) {
        localStorage.setItem('pos_products', JSON.stringify(SEED_PRODUCTS));
    }
    if (!localStorage.getItem('pos_sales')) {
        const now = Date.now();
        const initialSales = [
            {
                id: 1,
                invoice_no: `INV-${todayStr.replace(/-/g, '')}-0001`,
                sale_date: new Date(now - 1000 * 60 * 50).toISOString(),
                subtotal: 296.00,
                discount_rate: 5.0,
                discount_amount: 14.80,
                gst_rate: 18.0,
                gst_amount: 50.62,
                grand_total: 331.82,
                payment_method: 'Cash',
                cash_received: 350.00,
                change_amount: 18.18,
                notes: 'Counter Checkout',
                items: [
                    { product_name: 'Royal Basmati Rice 1kg', barcode: '890103038101', quantity: 2, unit_price: 120.00, line_total: 240.00 },
                    { product_name: 'Maggi 2-Minute Noodles 280g', barcode: '890103038305', quantity: 1, unit_price: 56.00, line_total: 56.00 }
                ]
            },
            {
                id: 2,
                invoice_no: `INV-${todayStr.replace(/-/g, '')}-0002`,
                sale_date: new Date(now - 1000 * 60 * 20).toISOString(),
                subtotal: 485.00,
                discount_rate: 0.0,
                discount_amount: 0.0,
                gst_rate: 18.0,
                gst_amount: 87.30,
                grand_total: 572.30,
                payment_method: 'UPI',
                cash_received: null,
                change_amount: null,
                notes: 'UPI Scanner',
                items: [
                    { product_name: 'Aashirvaad Whole Wheat Atta 5kg', barcode: '890103038102', quantity: 1, unit_price: 245.00, line_total: 245.00 },
                    { product_name: 'Fortune Sunlite Refined Oil 1L', barcode: '890103038103', quantity: 1, unit_price: 155.00, line_total: 155.00 },
                    { product_name: 'Cadbury Dairy Milk Silk 60g', barcode: '890103038303', quantity: 1, unit_price: 85.00, line_total: 85.00 }
                ]
            },
            {
                id: 3,
                invoice_no: `INV-${new Date(now - 86400000).toISOString().split('T')[0].replace(/-/g, '')}-0001`,
                sale_date: new Date(now - 86400000).toISOString(),
                subtotal: 380.00,
                discount_rate: 10.0,
                discount_amount: 38.00,
                gst_rate: 18.0,
                gst_amount: 61.56,
                grand_total: 403.56,
                payment_method: 'Card',
                cash_received: null,
                change_amount: null,
                notes: 'Card Swipe',
                items: [
                    { product_name: 'Taj Mahal Tea 250g', barcode: '890103038202', quantity: 2, unit_price: 170.00, line_total: 340.00 },
                    { product_name: 'Coca Cola Can 300ml', barcode: '890103038205', quantity: 1, unit_price: 40.00, line_total: 40.00 }
                ]
            }
        ];
        localStorage.setItem('pos_sales', JSON.stringify(initialSales));
    }
}

initStore();

const POS = {
    info: STORE_INFO,

    getProducts() {
        return JSON.parse(localStorage.getItem('pos_products') || '[]');
    },

    saveProducts(products) {
        localStorage.setItem('pos_products', JSON.stringify(products));
    },

    addProduct(data) {
        const products = this.getProducts();
        const barcodeExists = products.some(p => p.barcode === data.barcode);
        if (barcodeExists) {
            throw new Error(`Barcode ${data.barcode} is already assigned to another product.`);
        }
        const newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
        const newProduct = {
            id: newId,
            name: data.name.trim(),
            barcode: data.barcode.trim(),
            category: data.category.trim() || 'General',
            selling_price: parseFloat(data.selling_price),
            stock: parseInt(data.stock),
            min_stock: parseInt(data.min_stock) || 5
        };
        products.push(newProduct);
        this.saveProducts(products);
        return newProduct;
    },

    updateProduct(id, data) {
        const products = this.getProducts();
        const conflict = products.some(p => p.barcode === data.barcode && p.id !== id);
        if (conflict) {
            throw new Error(`Barcode ${data.barcode} is already in use.`);
        }
        const idx = products.findIndex(p => p.id === id);
        if (idx === -1) throw new Error('Product not found.');

        products[idx] = {
            ...products[idx],
            name: data.name.trim(),
            barcode: data.barcode.trim(),
            category: data.category.trim() || 'General',
            selling_price: parseFloat(data.selling_price),
            stock: parseInt(data.stock),
            min_stock: parseInt(data.min_stock) || 5
        };
        this.saveProducts(products);
        return products[idx];
    },

    deleteProduct(id) {
        let products = this.getProducts();
        products = products.filter(p => p.id !== id);
        this.saveProducts(products);
    },

    restockProduct(id, addQty) {
        const products = this.getProducts();
        const product = products.find(p => p.id === id);
        if (product) {
            product.stock += parseInt(addQty);
            this.saveProducts(products);
        }
    },

    getSales() {
        return JSON.parse(localStorage.getItem('pos_sales') || '[]');
    },

    saveSales(sales) {
        localStorage.setItem('pos_sales', JSON.stringify(sales));
    },

    getSaleByInvoice(invNo) {
        const sales = this.getSales();
        return sales.find(s => s.invoice_no === invNo);
    },

    checkout({ items, discount_rate = 0, gst_rate = 18, payment_method = 'Cash', cash_received = null, notes = '' }) {
        if (!items || items.length === 0) {
            throw new Error('Cannot checkout with an empty cart.');
        }

        const products = this.getProducts();
        let subtotal = 0;
        const lineItems = [];

        // Validate stock and deduct
        for (const item of items) {
            const prod = products.find(p => p.id === item.product_id);
            if (!prod) throw new Error(`Product not found.`);
            if (prod.stock < item.quantity) {
                throw new Error(`Insufficient stock for "${prod.name}". Available: ${prod.stock}, requested: ${item.quantity}.`);
            }
            const lineTotal = prod.selling_price * item.quantity;
            subtotal += lineTotal;
            prod.stock -= item.quantity; // Deduct

            lineItems.push({
                product_id: prod.id,
                product_name: prod.name,
                barcode: prod.barcode,
                quantity: item.quantity,
                unit_price: prod.selling_price,
                line_total: lineTotal
            });
        }

        const discountAmount = (subtotal * discount_rate) / 100;
        const taxableAmount = Math.max(0, subtotal - discountAmount);
        const gstAmount = (taxableAmount * gst_rate) / 100;
        const grandTotal = taxableAmount + gstAmount;

        let changeAmount = null;
        if (payment_method === 'Cash') {
            if (cash_received !== null && cash_received >= grandTotal) {
                changeAmount = cash_received - grandTotal;
            } else {
                cash_received = grandTotal;
                changeAmount = 0;
            }
        }

        // Generate Invoice Number: INV-YYYYMMDD-XXXX
        const sales = this.getSales();
        const todayStr = new Date().toISOString().split('T')[0].replace(/-/g, '');
        const count = sales.filter(s => s.invoice_no.startsWith(`INV-${todayStr}`)).length + 1;
        const invoiceNo = `INV-${todayStr}-${String(count).padStart(4, '0')}`;

        const saleRecord = {
            id: sales.length > 0 ? Math.max(...sales.map(s => s.id)) + 1 : 1,
            invoice_no: invoiceNo,
            sale_date: new Date().toISOString(),
            subtotal: subtotal,
            discount_rate: discount_rate,
            discount_amount: discountAmount,
            gst_rate: gst_rate,
            gst_amount: gstAmount,
            grand_total: grandTotal,
            payment_method: payment_method,
            cash_received: cash_received,
            change_amount: changeAmount,
            notes: notes,
            items: lineItems
        };

        sales.unshift(saleRecord); // Prepend so latest is first
        this.saveSales(sales);
        this.saveProducts(products); // Commit deducted stock

        return saleRecord;
    },

    getStats() {
        const sales = this.getSales();
        const products = this.getProducts();

        const todayStr = new Date().toISOString().split('T')[0];
        const todaySales = sales.filter(s => s.sale_date.startsWith(todayStr));

        const todayRevenue = todaySales.reduce((sum, s) => sum + s.grand_total, 0);
        const todayBills = todaySales.length;
        const totalProducts = products.length;
        const inventoryValuation = products.reduce((sum, p) => sum + (p.selling_price * p.stock), 0);
        const lowStockCount = products.filter(p => p.stock <= p.min_stock).length;
        const lowStockItems = products.filter(p => p.stock <= p.min_stock).sort((a,b) => a.stock - b.stock);

        return {
            todayRevenue,
            todayBills,
            totalProducts,
            inventoryValuation,
            lowStockCount,
            lowStockItems,
            recentSales: sales.slice(0, 5)
        };
    }
};
